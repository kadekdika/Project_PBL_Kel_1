<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 text-sm text-gray-400">
            <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-[#2d6a4f]">Dashboard</a>
            <span>›</span>
            <span class="text-gray-600 font-medium">Akuntansi</span>
            <span>›</span>
            <span class="text-gray-600 font-medium">Beban Operasional</span>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-800">Beban Operasional</h2>
        <p class="text-xs text-gray-400 mb-6">Catat pengeluaran operasional toko (gaji, sewa, listrik, dll)</p>

        <?php if(session('success')): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded-lg mb-4"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-4"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('akuntansi.beban.store')); ?>" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Tanggal</label>
                <input type="date" name="tanggal" value="<?php echo e(old('tanggal', now()->toDateString())); ?>" required
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Jenis Beban</label>
                <select name="id_akun" required class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f] bg-white">
                    <option value="">— Pilih Jenis Beban —</option>
                    <?php $__currentLoopData = $akunBeban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->id_akun); ?>"><?php echo e($a->kode_akun); ?> — <?php echo e($a->nama_akun); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Nama Beban / Keterangan</label>
                <input type="text" name="nama_beban" value="<?php echo e(old('nama_beban')); ?>" required maxlength="150"
                       placeholder="cth: Gaji karyawan bulan September"
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Jumlah (Rp)</label>
                <input type="number" name="jumlah" value="<?php echo e(old('jumlah')); ?>" required min="1"
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
            </div>
            <div class="md:col-span-2 xl:col-span-1 flex items-end">
                <button type="submit" class="bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-6 py-2.5 rounded-lg transition w-full">
                    Simpan Beban
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="font-bold text-gray-800">Riwayat Beban</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase">
                        <th class="px-6 py-3 rounded-l-lg">Tanggal</th>
                        <th class="px-4 py-3">Jenis Beban</th>
                        <th class="px-4 py-3">Nama Beban</th>
                        <th class="px-4 py-3">Keterangan</th>
                        <th class="px-4 py-3 text-right">Jumlah</th>
                        <th class="px-4 py-3">Oleh</th>
                        <th class="px-4 py-3 rounded-r-lg text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $beban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-3 text-gray-600 whitespace-nowrap"><?php echo e(\Carbon\Carbon::parse($b->tanggal)->format('d M Y')); ?></td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <span class="font-mono text-xs text-gray-400"><?php echo e($b->akun->kode_akun); ?></span>
                                <?php echo e($b->akun->nama_akun); ?>

                            </td>
                            <td class="px-4 py-3 font-medium text-gray-800"><?php echo e($b->nama_beban); ?></td>
                            <td class="px-4 py-3 text-gray-500"><?php echo e($b->keterangan); ?></td>
                            <td class="px-4 py-3 text-right font-bold tabular-nums text-red-600">Rp <?php echo e(number_format($b->jumlah, 0, ',', '.')); ?></td>
                            <td class="px-4 py-3 text-gray-500"><?php echo e($b->user->name ?? '-'); ?></td>
                            <td class="px-4 py-3 text-right">
                                <form method="POST" action="<?php echo e(route('akuntansi.beban.destroy', $b->id_beban)); ?>" onsubmit="return confirm('Hapus beban <?php echo e($b->nama_beban); ?>?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="text-red-500 hover:text-red-700 text-xs font-semibold">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="px-6 py-8 text-center text-gray-400">Belum ada beban operasional.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/akuntansi/beban.blade.php ENDPATH**/ ?>