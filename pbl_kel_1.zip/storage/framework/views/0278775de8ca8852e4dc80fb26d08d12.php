<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 text-sm text-gray-400">
            <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-[#2d6a4f]">Dashboard</a>
            <span>›</span>
            <span class="text-gray-600 font-medium">Akuntansi</span>
            <span>›</span>
            <span class="text-gray-600 font-medium">Buku Besar</span>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-lg border border-gray-200 p-6">

        <div class="flex items-start justify-between mb-6">
            <div>
                <h2 class="text-xl font-bold text-gray-800">Buku Besar</h2>
                <p class="text-xs text-gray-400">Ringkasan saldo akun dari jurnal umum</p>
            </div>
        </div>

        
        <form method="GET" action="<?php echo e(route('akuntansi.buku-besar')); ?>" class="flex items-end gap-4 mb-6 flex-wrap">
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Akun</label>
                <select name="akun" class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f] min-w-[220px]">
                    <option value="semua" <?php echo e(($akunId ?? 'semua') === 'semua' ? 'selected' : ''); ?>>Semua Akun</option>
                    <?php $__currentLoopData = $akunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->id_akun); ?>" <?php echo e(($akunId ?? '') == $a->id_akun ? 'selected' : ''); ?>>
                            <?php echo e($a->kode_akun); ?> — <?php echo e($a->nama_akun); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Periode</label>
                <div class="flex items-center gap-2">
                    <input type="date" name="dari" value="<?php echo e($dari); ?>"
                           class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
                    <span class="text-gray-400 text-sm">—</span>
                    <input type="date" name="sampai" value="<?php echo e($sampai); ?>"
                           class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
                </div>
            </div>
            <button type="submit" class="bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-5 py-2 rounded-lg transition">Filter</button>
        </form>

        <?php if(isset($akun)): ?>
            
            <div class="flex items-center justify-between mb-4">
                <h3 class="font-bold text-gray-800">
                    <?php echo e($akun->kode_akun); ?> — <?php echo e($akun->nama_akun); ?>

                    <span class="ml-2 text-[11px] px-2 py-0.5 rounded <?php echo e($akun->pos_saldo === 'debet' ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'); ?> font-bold">
                        Saldo Normal <?php echo e(ucfirst($akun->pos_saldo)); ?>

                    </span>
                </h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase">
                            <th class="px-4 py-3 rounded-l-lg">Tanggal</th>
                            <th class="px-4 py-3">No. Jurnal</th>
                            <th class="px-4 py-3">Keterangan</th>
                            <th class="px-4 py-3 text-right">Debet</th>
                            <th class="px-4 py-3 text-right">Kredit</th>
                            <th class="px-4 py-3 text-right rounded-r-lg">Saldo</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $mutasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 text-gray-600"><?php echo e(\Carbon\Carbon::parse($row->jurnal->tanggal)->format('d M Y')); ?></td>
                                <td class="px-4 py-3 font-mono text-xs text-gray-500"><?php echo e($row->jurnal->no_jurnal); ?></td>
                                <td class="px-4 py-3 text-gray-800"><?php echo e($row->jurnal->keterangan); ?></td>
                                <td class="px-4 py-3 text-right tabular-nums"><?php echo e($row->debet ? 'Rp ' . number_format($row->debet, 0, ',', '.') : ''); ?></td>
                                <td class="px-4 py-3 text-right tabular-nums"><?php echo e($row->kredit ? 'Rp ' . number_format($row->kredit, 0, ',', '.') : ''); ?></td>
                                <td class="px-4 py-3 text-right font-bold tabular-nums <?php echo e($row->saldo_berjalan >= 0 ? 'text-[#2d6a4f]' : 'text-red-500'); ?>">
                                    <?php echo e($row->saldo_berjalan < 0 ? '-' : ''); ?>Rp <?php echo e(number_format(abs($row->saldo_berjalan), 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6" class="px-4 py-8 text-center text-gray-400">Tidak ada mutasi pada periode ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase">
                            <th class="px-4 py-3 rounded-l-lg">Kode</th>
                            <th class="px-4 py-3">Nama Akun</th>
                            <th class="px-4 py-3 text-right">Total Debet</th>
                            <th class="px-4 py-3 text-right">Total Kredit</th>
                            <th class="px-4 py-3 text-right rounded-r-lg">Saldo</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $ringkasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 font-mono text-gray-700"><?php echo e($r->kode_akun); ?></td>
                                <td class="px-4 py-3 font-medium text-gray-800"><?php echo e($r->nama_akun); ?></td>
                                <td class="px-4 py-3 text-right tabular-nums">Rp <?php echo e(number_format($r->total_debet, 0, ',', '.')); ?></td>
                                <td class="px-4 py-3 text-right tabular-nums">Rp <?php echo e(number_format($r->total_kredit, 0, ',', '.')); ?></td>
                                <td class="px-4 py-3 text-right font-bold tabular-nums <?php echo e($r->saldo >= 0 ? 'text-[#2d6a4f]' : 'text-red-500'); ?>">
                                    <?php echo e($r->saldo < 0 ? '-' : ''); ?>Rp <?php echo e(number_format(abs($r->saldo), 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="px-4 py-8 text-center text-gray-400">Belum ada jurnal pada periode ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/akuntansi/buku-besar.blade.php ENDPATH**/ ?>