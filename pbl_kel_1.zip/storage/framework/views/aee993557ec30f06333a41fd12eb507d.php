<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 text-sm text-gray-400">
            <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-[#2d6a4f]">Dashboard</a>
            <span>›</span>
            <span class="text-gray-600 font-medium">Diskon</span>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div class="flex items-center justify-between mb-5">
            <div>
                <h2 class="text-xl font-bold text-gray-800">Data Diskon</h2>
                <p class="text-xs text-gray-400">Kelola promo dan diskon produk</p>
            </div>
            <a href="<?php echo e(route('diskon.create')); ?>">
                <button class="bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-4 py-2 rounded-xl transition">
                    + Tambah
                </button>
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-sm">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-gray-100 text-gray-500 text-xs">
                    <th class="pb-3 text-left font-semibold">Nama Diskon</th>
                    <th class="pb-3 text-left font-semibold">Besar</th>
                    <th class="pb-3 text-left font-semibold">Lokasi</th>
                    <th class="pb-3 text-left font-semibold">Pelanggan</th>
                    <th class="pb-3 text-left font-semibold">Min. Beli Eceran</th>
                    <th class="pb-3 text-left font-semibold">Min. Beli Grosir</th>
                    <th class="pb-3 text-left font-semibold">Periode</th>
                    <th class="pb-3 text-left font-semibold">Produk</th>
                    <th class="pb-3 text-left font-semibold">Status</th>
                    <th class="pb-3 text-left font-semibold">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                    <td class="py-3 font-medium text-gray-800"><?php echo e($d->nama_diskon); ?></td>
                    <td class="py-3 text-gray-600"><?php echo e($d->besar_diskon); ?>%</td>
                    <td class="py-3">
                        <?php if($d->lokasi_berlaku === 'semua'): ?>
                            <span class="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-lg text-xs font-semibold">Semua</span>
                        <?php elseif($d->lokasi_berlaku === 'gudang'): ?>
                            <span class="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold">Gudang</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 bg-green-100 text-green-700 rounded-lg text-xs font-semibold">Toko</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-3">
                        <?php if($d->id_pelanggan): ?>
                            <span class="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold">
                                <?php echo e($d->pelanggan->nama_pelanggan ?? '-'); ?>

                            </span>
                        <?php else: ?>
                            <span class="text-gray-400 text-xs">Semua</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 text-gray-600"><?php echo e($d->minimal_beli); ?> pcs</td>
                    <td class="py-3 text-gray-600"><?php echo e($d->minimal_beli_grosir); ?> pcs</td>
                    <td class="py-3 text-gray-500 text-xs">
                        <?php echo e($d->mulai_tgl->format('d/m/Y')); ?> — <?php echo e($d->selesai_tgl->format('d/m/Y')); ?>

                    </td>
                    <td class="py-3 text-gray-600">
                        <div class="flex flex-wrap gap-1">
                            <?php $__currentLoopData = $d->produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="px-2 py-0.5 bg-green-100 text-green-700 rounded-lg text-xs"><?php echo e($p->nama_produk); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </td>
                    <td class="py-3">
                        <?php if($d->isAktifHariIni()): ?>
                            <span class="px-2 py-1 bg-green-100 text-green-700 rounded-lg text-xs font-semibold">Aktif</span>
                        <?php elseif(!$d->is_aktif): ?>
                            <span class="px-2 py-1 bg-gray-100 text-gray-500 rounded-lg text-xs font-semibold">Nonaktif</span>
                        <?php else: ?>
                            <span class="px-2 py-1 bg-yellow-100 text-yellow-600 rounded-lg text-xs font-semibold">Belum/Kadaluarsa</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-3">
                        <div class="flex items-center gap-2">
                            <a href="<?php echo e(route('diskon.edit', $d->id_diskon)); ?>"
                               class="w-8 h-8 bg-yellow-100 hover:bg-yellow-200 rounded-lg flex items-center justify-center transition">
                                <svg class="w-4 h-4 text-yellow-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                </svg>
                            </a>
                            <form action="<?php echo e(route('diskon.destroy', $d->id_diskon)); ?>" method="POST"
                                  onsubmit="return confirm('Yakin hapus diskon ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="w-8 h-8 bg-red-100 hover:bg-red-200 rounded-lg flex items-center justify-center transition">
                                    <svg class="w-4 h-4 text-red-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="py-10 text-center text-gray-400">Belum ada data diskon</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/diskon/index.blade.php ENDPATH**/ ?>