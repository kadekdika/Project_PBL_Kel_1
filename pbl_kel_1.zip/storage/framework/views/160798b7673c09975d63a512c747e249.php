<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('header', null, []); ?> <h2 class="text-xl font-bold">Sampah Kategori</h2> <?php $__env->endSlot(); ?>
<div class="bg-white rounded-lg border p-5">
    <a href="<?php echo e(route('kategori.index')); ?>" class="text-sm text-[#2d6a4f]">← Kembali</a>
    <table class="w-full text-sm mt-4">
        <thead><tr class="text-gray-400 text-xs"><th>Nama</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sampah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-b">
                <td class="py-2"><?php echo e($s->nama_kategori); ?></td>
                <td><span class="text-xs bg-gray-100 px-2 py-0.5 rounded">Dihapus</span></td>
                <td class="flex gap-2">
                    <form action="<?php echo e(route('kategori.pulihkan', $s->id_kategori)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?> <button class="px-3 py-1 bg-[#2d6a4f] text-white text-xs rounded">Pulihkan</button>
                    </form>
                    <form action="<?php echo e(route('kategori.hapusPermanen', $s->id_kategori)); ?>" method="POST" class="inline" onsubmit="return confirm('Hapus permanen? Tidak bisa di-undo.')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <button class="px-3 py-1 bg-red-600 text-white text-xs rounded">Hapus Permanen</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3" class="text-center text-gray-400 py-4">Tidak ada kategori di sampah</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/kategori/sampah.blade.php ENDPATH**/ ?>