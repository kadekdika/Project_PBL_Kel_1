<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 text-sm text-gray-400">
            <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-[#2d6a4f]">Dashboard</a>
            <span>›</span>
            <span class="text-gray-600 font-medium">Akuntansi</span>
            <span>›</span>
            <span class="text-gray-600 font-medium">Neraca</span>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-lg border border-gray-200 p-6">
        <div class="flex items-start justify-between mb-6">
            <div>
                <h2 class="text-xl font-bold text-gray-800">Neraca</h2>
                <p class="text-xs text-gray-400">Posisi keuangan per <b><?php echo e(\Carbon\Carbon::parse($sampai)->format('d M Y')); ?></b></p>
            </div>
            <button onclick="window.print()"
                    class="flex items-center gap-2 bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-4 py-2 rounded-lg transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
                </svg>
                Cetak
            </button>
        </div>

        <form method="GET" action="<?php echo e(route('akuntansi.neraca')); ?>" class="flex items-end gap-4 mb-6">
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Tanggal Neraca</label>
                <input type="date" name="sampai" value="<?php echo e($sampai); ?>"
                       class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
            </div>
            <button type="submit" class="bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-5 py-2 rounded-lg transition">Filter</button>
        </form>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <div class="border border-gray-200 rounded-lg overflow-hidden">
                <div class="bg-gray-50 px-5 py-4 border-b border-gray-200">
                    <h3 class="font-bold text-gray-800 text-lg">ASET</h3>
                </div>
                <div class="divide-y divide-gray-100">
                    <div class="px-5 py-2.5 bg-gray-50/50 text-xs font-bold text-gray-500 uppercase">Aktiva Lancar</div>
                    <?php $__currentLoopData = $aktiva->where('akun.kategori_neraca', 'aktiva_lancar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between px-5 py-3">
                            <span class="text-sm text-gray-700">
                                <span class="font-mono text-xs text-gray-400"><?php echo e($a['akun']->kode_akun); ?></span>
                                <?php echo e($a['akun']->nama_akun); ?>

                            </span>
                            <span class="text-sm font-semibold tabular-nums">Rp <?php echo e(number_format($a['saldo'], 0, ',', '.')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="px-5 py-2.5 bg-gray-50/50 text-xs font-bold text-gray-500 uppercase">Aktiva Tetap</div>
                    <?php $__currentLoopData = $aktiva->where('akun.kategori_neraca', 'aktiva_tetap'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between px-5 py-3">
                            <span class="text-sm text-gray-700">
                                <span class="font-mono text-xs text-gray-400"><?php echo e($a['akun']->kode_akun); ?></span>
                                <?php echo e($a['akun']->nama_akun); ?>

                            </span>
                            <span class="text-sm font-semibold tabular-nums">Rp <?php echo e(number_format($a['saldo'], 0, ',', '.')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between px-5 py-4 bg-gray-50 border-t border-gray-200">
                        <span class="font-bold text-gray-800">TOTAL ASET</span>
                        <span class="font-black text-lg tabular-nums text-[#2d6a4f]">Rp <?php echo e(number_format($totalAktiva, 0, ',', '.')); ?></span>
                    </div>
                </div>
            </div>

            
            <div class="border border-gray-200 rounded-lg overflow-hidden">
                <div class="bg-gray-50 px-5 py-4 border-b border-gray-200">
                    <h3 class="font-bold text-gray-800 text-lg">KEWAJIBAN & MODAL</h3>
                </div>
                <div class="divide-y divide-gray-100">
                    <div class="px-5 py-2.5 bg-gray-50/50 text-xs font-bold text-gray-500 uppercase">Kewajiban</div>
                    <?php $__currentLoopData = $kewajiban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between px-5 py-3">
                            <span class="text-sm text-gray-700">
                                <span class="font-mono text-xs text-gray-400"><?php echo e($k['akun']->kode_akun); ?></span>
                                <?php echo e($k['akun']->nama_akun); ?>

                            </span>
                            <span class="text-sm font-semibold tabular-nums">Rp <?php echo e(number_format($k['saldo'], 0, ',', '.')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="px-5 py-2.5 bg-gray-50/50 text-xs font-bold text-gray-500 uppercase">Modal</div>
                    <?php $__currentLoopData = $modalItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between px-5 py-3">
                            <span class="text-sm text-gray-700">
                                <span class="font-mono text-xs text-gray-400"><?php echo e($m['akun']->kode_akun); ?></span>
                                <?php echo e($m['akun']->nama_akun); ?>

                            </span>
                            <span class="text-sm font-semibold tabular-nums <?php echo e($m['saldo'] < 0 ? 'text-red-500' : ''); ?>">
                                <?php echo e($m['saldo'] < 0 ? '(' : ''); ?>Rp <?php echo e(number_format(abs($m['saldo']), 0, ',', '.')); ?><?php echo e($m['saldo'] < 0 ? ')' : ''); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between px-5 py-3">
                        <span class="text-sm text-gray-700">Laba Ditahan</span>
                        <span class="text-sm font-semibold tabular-nums <?php echo e($labaDitahan < 0 ? 'text-red-500' : 'text-[#2d6a4f]'); ?>">
                            <?php echo e($labaDitahan < 0 ? '(' : ''); ?>Rp <?php echo e(number_format(abs($labaDitahan), 0, ',', '.')); ?><?php echo e($labaDitahan < 0 ? ')' : ''); ?>

                        </span>
                    </div>

                    <div class="flex items-center justify-between px-5 py-4 bg-gray-50 border-t border-gray-200">
                        <span class="font-bold text-gray-800">TOTAL KEWAJIBAN & MODAL</span>
                        <span class="font-black text-lg tabular-nums text-[#2d6a4f]">Rp <?php echo e(number_format($totalPasiva, 0, ',', '.')); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4 grid grid-cols-3 gap-4 text-center">
            <div class="text-xs text-gray-500">Total Aset</div>
            <div class="text-xs text-gray-500">Total Kewajiban</div>
            <div class="text-xs text-gray-500">Total Modal</div>
            <div class="font-bold tabular-nums">Rp <?php echo e(number_format($totalAktiva, 0, ',', '.')); ?></div>
            <div class="font-bold tabular-nums">Rp <?php echo e(number_format($totalKewajiban, 0, ',', '.')); ?></div>
            <div class="font-bold tabular-nums">Rp <?php echo e(number_format($totalModal, 0, ',', '.')); ?></div>
        </div>

        <?php if($totalAktiva !== $totalPasiva): ?>
            <div class="mt-4 bg-amber-50 border border-amber-200 text-amber-700 text-sm px-4 py-3 rounded-lg">
                Perhatian: Total aset (Rp <?php echo e(number_format($totalAktiva, 0, ',', '.')); ?>) tidak sama dengan total kewajiban & modal (Rp <?php echo e(number_format($totalPasiva, 0, ',', '.')); ?>). Periksa jurnal pembuka modal.
            </div>
        <?php endif; ?>

        <p class="text-[11px] text-gray-400 mt-4">
            * Untuk saldo awal realistis, buat jurnal manual setoran modal: Debet <span class="font-mono">1101 Kas</span> — Kredit <span class="font-mono">3101 Modal Pemilik</span>.
        </p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/akuntansi/neraca.blade.php ENDPATH**/ ?>