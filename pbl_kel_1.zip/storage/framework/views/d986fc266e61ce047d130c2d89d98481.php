<?php $__env->startSection('content'); ?>
<div class="p-8">
    
    <div class="mb-10">
        <h2 class="text-3xl font-black text-[#2d6a4f] tracking-tight">Kustomisasi Visual</h2>
        <p class="text-gray-400 text-sm font-medium italic">Kelola branding toko anda.</p>
    </div>

    
    <div class="space-y-10">
        <form action="<?php echo e(route('landing.update')); ?>" method="POST" enctype="multipart/form-data" class="bg-white p-8 rounded-[2.5rem] border shadow-sm">
            <?php echo csrf_field(); ?>
            <h4 class="font-black text-gray-800 uppercase tracking-tighter mb-6">Pengaturan Visual Login</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                <div class="space-y-4">
                    <div>
                        <label class="text-[10px] font-bold uppercase text-gray-400">Judul Login</label>
                        <input type="text" name="login_title" value="<?php echo e($data->login_title ?? ''); ?>" class="w-full p-4 bg-gray-50 rounded-2xl border outline-none">
                    </div>
                    <div>
                        <label class="text-[10px] font-bold uppercase text-gray-400">Subtitle</label>
                        <input type="text" name="login_subtitle" value="<?php echo e($data->login_subtitle ?? ''); ?>" class="w-full p-4 bg-gray-50 rounded-2xl border outline-none">
                    </div>
                    <div>
                        <label class="text-[10px] font-bold uppercase text-gray-400">Font</label>
                        <select name="login_font_family" class="w-full p-4 bg-gray-50 rounded-2xl border outline-none text-sm">
                            <?php
                                $fonts = [
                                    "'Plus Jakarta Sans', sans-serif" => 'Plus Jakarta Sans (Default)',
                                    "'Inter', sans-serif"             => 'Inter',
                                    "'Poppins', sans-serif"           => 'Poppins',
                                    "'Montserrat', sans-serif"        => 'Montserrat',
                                    "'Nunito', sans-serif"            => 'Nunito',
                                    "'DM Sans', sans-serif"           => 'DM Sans',
                                ];
                            ?>
                            <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php echo e(($data->login_font_family ?? "'Plus Jakarta Sans', sans-serif") == $value ? 'selected' : ''); ?>>
                                    <?php echo e($label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                
                <div class="space-y-4">
                    <div>
                        <label class="text-[10px] font-bold uppercase text-gray-400">Warna Panel Kiri</label>
                        <input type="color" name="login_bg_color" value="<?php echo e($data->login_bg_color ?? '#2d6a4f'); ?>" class="w-full h-14 p-1 bg-gray-50 rounded-2xl border outline-none">
                    </div>
                    <div>
                        <label class="text-[10px] font-bold uppercase text-gray-400">Warna Teks & Tombol</label>
                        <input type="color" name="login_text_color" value="<?php echo e($data->login_text_color ?? '#2d6a4f'); ?>" class="w-full h-14 p-1 bg-gray-50 rounded-2xl border outline-none">
                    </div>
                    <div>
                        <label class="text-[10px] font-bold uppercase text-gray-400">Logo Besar (Panel Kiri)</label>
                        <input type="file" name="login_logo" class="w-full p-3 bg-gray-50 rounded-2xl border text-xs">
                        <?php if($data->login_logo_path): ?>
                            <img src="<?php echo e(asset('storage/' . $data->login_logo_path)); ?>" class="mt-2 h-12 object-contain rounded-xl border p-1">
                        <?php endif; ?>
                    </div>
                    <div>
                        <label class="text-[10px] font-bold uppercase text-gray-400">Foto Hero (Panel Kiri Login)</label>
                        <input type="file" name="login_hero" accept="image/*" class="w-full p-3 bg-gray-50 rounded-2xl border text-xs">
                        <p class="text-[10px] text-gray-400 mt-1">Foto latar belakang panel kiri login. Jika kosong, menggunakan warna solid.</p>
                        <?php if($data->login_hero_image): ?>
                            <img src="<?php echo e(asset('storage/' . $data->login_hero_image)); ?>" class="mt-2 h-20 w-full object-cover rounded-xl border">
                        <?php endif; ?>
                    </div>

                </div>
            </div>
            <button type="submit" class="mt-8 bg-blue-600 text-white px-10 py-3 rounded-xl font-bold">Simpan Visual Login</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/Pengaturan/landing.blade.php ENDPATH**/ ?>