function undoDelete(data) {
    if (!data || !data.model_class || !data.model_id) return;
    const el = document.createElement('div');
    el.className = 'fixed bottom-4 right-4 z-50 bg-[#2d6a4f] text-white px-3 py-2 rounded-lg shadow-xl text-xs max-w-xs flex items-center gap-2 border border-white/10';
    el.innerHTML = `<span class="font-medium">${data.message || 'Dihapus'}</span><button onclick="this.closest('.fixed').remove();clearTimeout(t);t=setTimeout(()=>this.closest('.fixed').remove(),5000);" class="bg-white/20 hover:bg-white/30 px-2 py-0.5 rounded text-[10px] font-semibold whitespace-nowrap">Urungkan</button><span class="text-[10px] text-white/60 ml-auto">5s</span>`;
    document.body.appendChild(el);
    const t = setTimeout(() => el.remove(), 5000);
}
