<?php
namespace App\Traits;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
trait HasUndoableDelete {
    protected function undoableDelete(Model $model, string $successMsg = 'Data berhasil dihapus', ?string $redirectUrl = null): \Illuminate\Http\RedirectResponse {
        $model->delete();
        return redirect($redirectUrl ?? url()->previous());
    }
    public function restore(string $modelClass, $id, Request $request): \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse {
        $model = new $modelClass();
        $instance = $model->withTrashed()->find($id);
        if (!$instance) return response()->json(['error'=>'Tidak ditemukan'],404);
        $instance->restore();
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Dipulihkan');
    }
}
