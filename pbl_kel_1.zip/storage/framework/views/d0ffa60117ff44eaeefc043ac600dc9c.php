<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 text-sm text-gray-400">
            <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-[#2d6a4f]">Dashboard</a>
            <span>›</span>
            <span class="text-gray-600 font-medium">Laporan</span>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-lg border border-gray-200 p-6">

        
        <div class="flex items-start justify-between mb-6">
            <div>
                <h2 class="text-xl font-bold text-gray-800">
                    Laporan <?php echo e($tab === 'pembelian' ? 'Pembelian' : 'Penjualan'); ?>

                </h2>
                <p class="text-xs text-gray-400">
                    Kelola dan pantau laporan <?php echo e($tab === 'pembelian' ? 'pembelian' : 'penjualan'); ?> toko
                </p>
            </div>
            <div class="flex items-center gap-2">
                <?php if(auth()->user()->role == 'pemilik' || auth()->user()->role == 'kasir'): ?>
                <a href="<?php echo e(route('laporan.export', ['dari' => $dari, 'sampai' => $sampai, 'tab' => $tab])); ?>"
                   class="flex items-center gap-2 bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-4 py-2 rounded-lg transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3M3 17V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
                    </svg>
                    Export Excel
                </a>
                <?php endif; ?>

                <button onclick="window.print()"
                        class="flex items-center gap-2 bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-4 py-2 rounded-lg transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
                    </svg>
                    Cetak Laporan
                </button>
            </div>
        </div>

        
        <form method="GET" action="<?php echo e(route('laporan.index')); ?>" class="mb-6" id="formLaporan">
            
            <input type="hidden" name="tab" value="<?php echo e($tab); ?>">
            <div class="flex flex-wrap items-end gap-3">
                <div>
                    <label class="block text-xs font-medium text-gray-500 mb-1">Periode Tanggal</label>
                    <div class="flex items-center gap-2">
                        <input type="date" name="dari" id="inputDari" value="<?php echo e($dari); ?>"
                               class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
                        <span class="text-gray-400 text-sm">—</span>
                        <input type="date" name="sampai" id="inputSampai" value="<?php echo e($sampai); ?>"
                               class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
                    </div>
                </div>
                <button type="submit"
                        class="bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-5 py-2 rounded-lg transition">
                    Filter
                </button>
            </div>

            
            <div class="flex flex-wrap gap-2 mt-3">
                <button type="button" onclick="setPeriode('bulan-ini')"
                        class="text-xs font-semibold px-3 py-1.5 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-600 transition">
                    Bulan Ini
                </button>
                <button type="button" onclick="setPeriode('3-bulan')"
                        class="text-xs font-semibold px-3 py-1.5 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-600 transition">
                    3 Bulan Terakhir
                </button>
                <button type="button" onclick="setPeriode('1-tahun')"
                        class="text-xs font-semibold px-3 py-1.5 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-600 transition">
                    1 Tahun Terakhir
                </button>
            </div>
        </form>

        <script>
        function setPeriode(tipe) {
            const dari   = document.getElementById('inputDari');
            const sampai = document.getElementById('inputSampai');
            const today  = new Date();
            let start    = new Date();

            if (tipe === 'bulan-ini') {
                start = new Date(today.getFullYear(), today.getMonth(), 1);
            } else if (tipe === '3-bulan') {
                start = new Date(today.getFullYear(), today.getMonth() - 3, today.getDate());
            } else if (tipe === '1-tahun') {
                start = new Date(today.getFullYear() - 1, today.getMonth(), today.getDate());
            }

            dari.value   = start.toISOString().split('T')[0];
            sampai.value = today.toISOString().split('T')[0];
            document.getElementById('formLaporan').submit();
        }
        </script>

        
        <div class="grid grid-cols-2 <?php echo e(auth()->user()->role == 'pemilik' ? 'lg:grid-cols-4' : 'lg:grid-cols-2'); ?> gap-4 mb-6">

            <div class="bg-white border border-gray-200 rounded-lg p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-9 h-9 bg-gray-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-[#2d6a4f]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                    </div>
                    <p class="text-xs font-medium text-gray-600">Total Penjualan</p>
                </div>
                <p class="text-xl font-bold text-gray-800">Rp <?php echo e(number_format($totalPenjualan, 0, ',', '.')); ?></p>
                <p class="text-xs text-gray-400 mt-1">Total semua transaksi</p>
            </div>

            <div class="bg-white border border-gray-200 rounded-lg p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-9 h-9 bg-gray-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-[#2d6a4f]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                        </svg>
                    </div>
                    <p class="text-xs font-medium text-gray-600">Total Transaksi</p>
                </div>
                <p class="text-xl font-bold text-gray-800"><?php echo e($totalTransaksi); ?></p>
                <p class="text-xs text-gray-400 mt-1">Jumlah transaksi</p>
            </div>

            <?php if(auth()->user()->role == 'pemilik'): ?>
            <div class="bg-white border border-gray-200 rounded-lg p-5">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-9 h-9 bg-gray-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-[#2d6a4f]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
                        </svg>
                    </div>
                    <p class="text-xs font-medium text-gray-600">Total Pembelian</p>
                </div>
                <p class="text-xl font-bold text-gray-800">Rp <?php echo e(number_format($totalPembelian, 0, ',', '.')); ?></p>
                <p class="text-xs text-gray-400 mt-1">Total pengeluaran</p>
            </div>

            <div class="border border-gray-200 rounded-lg p-5 <?php echo e($labaBersih >= 0 ? 'bg-white' : 'bg-red-50 border-red-100'); ?>">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-9 h-9 bg-gray-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 <?php echo e($labaBersih >= 0 ? 'text-[#2d6a4f]' : 'text-red-500'); ?>" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                    </div>
                    <p class="text-xs font-medium text-gray-600">Laba Bersih</p>
                </div>
                <p class="text-xl font-bold <?php echo e($labaBersih >= 0 ? 'text-[#2d6a4f]' : 'text-red-500'); ?>">
                    <?php echo e($labaBersih < 0 ? '-' : ''); ?>Rp <?php echo e(number_format(abs($labaBersih), 0, ',', '.')); ?>

                </p>
                <p class="text-xs text-gray-400 mt-1"><?php echo e($labaBersih >= 0 ? 'Untung' : 'Rugi'); ?> periode ini</p>
            </div>
            <?php endif; ?>

        </div>

        
        <div class="flex gap-1 mb-5 bg-gray-100 p-1 rounded-lg w-fit">
            <a href="<?php echo e(route('laporan.index', ['dari' => $dari, 'sampai' => $sampai, 'tab' => 'penjualan'])); ?>"
               class="px-5 py-2 rounded-lg text-sm font-semibold transition
                      <?php echo e($tab === 'penjualan' ? 'bg-white text-[#2d6a4f] shadow-sm' : 'text-gray-500 hover:text-gray-700'); ?>">
                Penjualan
            </a>
            <?php if(auth()->user()->role == 'pemilik'): ?>
            <a href="<?php echo e(route('laporan.index', ['dari' => $dari, 'sampai' => $sampai, 'tab' => 'pembelian'])); ?>"
               class="px-5 py-2 rounded-lg text-sm font-semibold transition
                      <?php echo e($tab === 'pembelian' ? 'bg-white text-[#2d6a4f] shadow-sm' : 'text-gray-500 hover:text-gray-700'); ?>">
                Pembelian
            </a>
            <?php endif; ?>
        </div>

        
        <?php if($tab === 'penjualan'): ?>
        <h3 class="font-bold text-gray-700 mb-3">Data Penjualan</h3>
        <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 text-gray-500 text-xs">
                    <th class="px-4 py-3 text-left font-semibold rounded-l-lg">No</th>
                    <th class="px-4 py-3 text-left font-semibold">Tanggal</th>
                    <th class="px-4 py-3 text-left font-semibold">Pelanggan</th>
                    <th class="px-4 py-3 text-left font-semibold">Produk</th>
                    <th class="px-4 py-3 text-left font-semibold">Total</th>
                    <th class="px-4 py-3 text-left font-semibold rounded-r-lg">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
                    <td class="px-4 py-3 text-gray-500"><?php echo e($transaksi->firstItem() + $i); ?></td>
                    <td class="px-4 py-3 text-gray-700"><?php echo e(\Carbon\Carbon::parse($t->tanggal)->format('d/m/Y')); ?></td>
                    <td class="px-4 py-3 text-gray-700"><?php echo e($t->pelanggan->nama_pelanggan ?? 'Umum'); ?></td>
                    <td class="px-4 py-3 text-gray-700"><?php echo e($t->detail->first()->produk->nama_produk ?? '-'); ?></td>
                    <td class="px-4 py-3 font-medium text-gray-800">Rp <?php echo e(number_format($t->total, 0, ',', '.')); ?></td>
                    <td class="px-4 py-3">
                        <a href="<?php echo e(route('transaksi.show', $t->id_transaksi)); ?>"
                           class="flex items-center gap-1 text-xs text-[#2d6a4f] font-semibold bg-gray-50 hover:bg-gray-100 px-3 py-1.5 rounded-lg transition w-fit">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                            Detail
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="py-10 text-center text-gray-400">Belum ada data penjualan</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>

        
       
        
<?php else: ?>
<h3 class="font-bold text-gray-700 mb-3">Data Pembelian</h3>
<div class="overflow-x-auto">
<table class="w-full text-sm">
    <thead>
        <tr class="bg-gray-50 text-gray-500 text-xs">
            <th class="px-4 py-3 text-left font-semibold rounded-l-lg">No</th>
            <th class="px-4 py-3 text-left font-semibold">Tanggal</th>
            <th class="px-4 py-3 text-left font-semibold">Supplier</th>
            <th class="px-4 py-3 text-left font-semibold">Produk</th>
            <th class="px-4 py-3 text-left font-semibold">Total</th>
            <th class="px-4 py-3 text-left font-semibold">Petugas</th>  
            <th class="px-4 py-3 text-left font-semibold rounded-r-lg">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-b border-gray-50 hover:bg-gray-50 transition">
            <td class="px-4 py-3 text-gray-500"><?php echo e($transaksi->firstItem() + $i); ?></td>
            <td class="px-4 py-3 text-gray-700"><?php echo e(\Carbon\Carbon::parse($t->tanggal)->format('d/m/Y')); ?></td>
            <td class="px-4 py-3 text-gray-700"><?php echo e($t->suplier->nama_suplier ?? '-'); ?></td>
            <td class="px-4 py-3 text-gray-700"><?php echo e($t->detail->first()->produk->nama_produk ?? '-'); ?></td>
            <td class="px-4 py-3 font-medium text-gray-800">Rp <?php echo e(number_format($t->total, 0, ',', '.')); ?></td>
            <td class="px-4 py-3 text-gray-700"><?php echo e($t->user->name ?? '-'); ?></td>  
            <td class="px-4 py-3">
                <a href="<?php echo e(route('pembelian.show', $t->id_transaksi)); ?>"
                   class="flex items-center gap-1 text-xs text-[#2d6a4f] font-semibold bg-gray-50 hover:bg-gray-100 px-3 py-1.5 rounded-lg transition w-fit">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                    </svg>
                    Detail
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7" class="py-10 text-center text-gray-400">Belum ada data pembelian</td>  
        </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>
<?php endif; ?>

        
        <div class="flex items-center justify-between mt-4">
            <p class="text-xs text-gray-400">
                Menampilkan <?php echo e($transaksi->firstItem() ?? 0); ?> - <?php echo e($transaksi->lastItem() ?? 0); ?> dari <?php echo e($transaksi->total()); ?> transaksi
            </p>
            <div class="flex items-center gap-1">
                <?php if($transaksi->onFirstPage()): ?>
                    <span class="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 text-gray-300">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
                        </svg>
                    </span>
                <?php else: ?>
                    <a href="<?php echo e($transaksi->previousPageUrl()); ?>&dari=<?php echo e($dari); ?>&sampai=<?php echo e($sampai); ?>&tab=<?php echo e($tab); ?>"
                       class="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 hover:bg-gray-100 transition">
                        <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
                        </svg>
                    </a>
                <?php endif; ?>

                <?php if($transaksi->hasMorePages()): ?>
                    <a href="<?php echo e($transaksi->nextPageUrl()); ?>&dari=<?php echo e($dari); ?>&sampai=<?php echo e($sampai); ?>&tab=<?php echo e($tab); ?>"
                       class="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 hover:bg-gray-100 transition">
                        <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                        </svg>
                    </a>
                <?php else: ?>
                    <span class="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 text-gray-300">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                        </svg>
                    </span>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <style>
        @media print {
            aside, header, .no-print, nav, button, form, a[href] { display: none !important; }
            main { padding: 0 !important; margin: 0 !important; }
            .bg-white { box-shadow: none !important; border: none !important; }
            .rounded-lg { border-radius: 0 !important; }
        }
    </style>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/laporan/index.blade.php ENDPATH**/ ?>