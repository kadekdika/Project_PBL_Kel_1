<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 text-sm text-gray-400">
            <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-[#2d6a4f]">Dashboard</a>
            <span>›</span>
            <span class="text-gray-600 font-medium">Riwayat Aktivitas</span>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
        $badgeAksi = [
            'penjualan_buat'   => ['Penjualan Dibuat', 'bg-green-100 text-green-700'],
            'penjualan_hapus'  => ['Penjualan Dihapus', 'bg-red-100 text-red-700'],
            'pembelian_buat'   => ['Pembelian Dibuat', 'bg-blue-100 text-blue-700'],
            'pembelian_hapus'  => ['Pembelian Dihapus', 'bg-red-100 text-red-700'],
            'login'            => ['Login', 'bg-gray-100 text-gray-600'],
            'logout'           => ['Logout', 'bg-gray-100 text-gray-600'],
        ];
        $badgeRole = [
            'pemilik'  => 'bg-green-100 text-green-700',
            'pemilik2' => 'bg-blue-100 text-blue-700',
            'kasir'    => 'bg-amber-100 text-amber-700',
        ];
    ?>

    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
        <div>
            <h2 class="text-xl font-bold text-gray-800">Riwayat Aktivitas</h2>
            <p class="text-xs text-gray-400">Jejak siapa melakukan apa — transaksi & login</p>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded-lg mb-4"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <!-- Filter -->
    <div class="bg-white rounded-lg border border-gray-200 p-4 mb-6">
        <form method="GET" action="<?php echo e(route('riwayat.index')); ?>" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-3">
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Dari</label>
                <input type="date" name="dari" value="<?php echo e($dari); ?>"
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Sampai</label>
                <input type="date" name="sampai" value="<?php echo e($sampai); ?>"
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Jenis Kejadian</label>
                <select name="kejadian" class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f] bg-white">
                    <option value="">Semua</option>
                    <option value="penjualan" <?php echo e($kejadian === 'penjualan' ? 'selected' : ''); ?>>Penjualan</option>
                    <option value="pembelian" <?php echo e($kejadian === 'pembelian' ? 'selected' : ''); ?>>Pembelian</option>
                    <option value="login" <?php echo e($kejadian === 'login' ? 'selected' : ''); ?>>Login / Logout</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1">Cari</label>
                <input type="text" name="cari" value="<?php echo e($cari); ?>" placeholder="cth: Penjualan #12"
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2d6a4f]">
            </div>
            <div class="flex items-end gap-2">
                <button type="submit" class="bg-[#2d6a4f] hover:bg-[#1b4332] text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition">
                    Filter
                </button>
                <?php if($dari || $sampai || $kejadian || $cari): ?>
                    <a href="<?php echo e(route('riwayat.index')); ?>" class="text-sm font-semibold text-gray-500 hover:text-gray-700 px-3 py-2.5">Reset</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Tabel Riwayat -->
    <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="font-bold text-gray-800">Semua Aktivitas <span class="text-xs font-normal text-gray-400">(<?php echo e($riwayat->count()); ?>)</span></h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-500 uppercase">
                        <th class="px-6 py-3 rounded-l-lg">Aksi</th>
                        <th class="px-4 py-3">Objek</th>
                        <th class="px-4 py-3 text-right">Total</th>
                        <th class="px-4 py-3 text-right">Waktu Aksi</th>
                        <th class="px-4 py-3">Oleh</th>
                        <th class="px-4 py-3">IP</th>
                        <?php if(auth()->user()->role === 'pemilik'): ?>
                            <th class="px-4 py-3 rounded-r-lg text-right">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php [$namaAksi, $warnaAksi] = $badgeAksi[$r->aksi] ?? [$r->aksi, 'bg-gray-100 text-gray-600']; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-3 whitespace-nowrap">
                                <span class="inline-block text-xs font-semibold px-2.5 py-1 rounded-full <?php echo e($warnaAksi); ?>"><?php echo e($namaAksi); ?></span>
                            </td>
                            <td class="px-4 py-3">
                                <div class="font-medium text-gray-800"><?php echo e($r->label); ?></div>
                                <details class="text-xs text-gray-400 mt-0.5">
                                    <summary class="cursor-pointer hover:text-[#2d6a4f]">detail</summary>
                                    <div class="mt-1 text-gray-500 space-y-0.5">
                                        <?php if($r->detail): ?>
                                            <?php if(isset($r->detail['jumlah_item'])): ?> <div>Jumlah item: <?php echo e($r->detail['jumlah_item']); ?></div> <?php endif; ?>
                                            <?php if(isset($r->detail['metode'])): ?> <div>Metode bayar: <?php echo e($r->detail['metode']); ?></div> <?php endif; ?>
                                            <?php if(isset($r->detail['id_pelanggan'])): ?> <div>Pelanggan ID: <?php echo e($r->detail['id_pelanggan']); ?></div> <?php endif; ?>
                                            <?php if(isset($r->detail['id_suplier'])): ?> <div>Suplier ID: <?php echo e($r->detail['id_suplier']); ?></div> <?php endif; ?>
                                            <?php if(!empty($r->detail['catatan'])): ?> <div>Catatan: <?php echo e($r->detail['catatan']); ?></div> <?php endif; ?>
                                        <?php else: ?>
                                            <div>—</div>
                                        <?php endif; ?>
                                    </div>
                                </details>
                            </td>
                            <td class="px-4 py-3 text-right tabular-nums <?php echo e($r->total > 0 ? 'font-bold text-gray-800' : 'text-gray-300'); ?>">
                                <?php echo e($r->total > 0 ? 'Rp ' . number_format($r->total, 0, ',', '.') : '—'); ?>

                            </td>
                            <td class="px-4 py-3 text-right whitespace-nowrap text-gray-600">
                                <?php echo e(\Carbon\Carbon::parse($r->created_at)->format('d M Y, H:i')); ?>

                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <span class="font-medium text-gray-700"><?php echo e($r->user->name ?? '—'); ?></span>
                                <?php if($r->role): ?>
                                    <span class="ml-1 inline-block text-xs font-semibold px-2 py-0.5 rounded-full <?php echo e($badgeRole[$r->role] ?? 'bg-gray-100 text-gray-600'); ?>"><?php echo e($r->role); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-xs text-gray-400 font-mono"><?php echo e($r->ip_address ?? '—'); ?></td>
                            <?php if(auth()->user()->role === 'pemilik'): ?>
                                <td class="px-4 py-3 text-right">
                                    <form method="POST" action="<?php echo e(route('riwayat.destroy', $r->id_riwayat)); ?>" onsubmit="return confirm('Hapus riwayat ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="text-red-500 hover:text-red-700 text-xs font-semibold">Hapus</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e(auth()->user()->role === 'pemilik' ? 7 : 6); ?>" class="px-6 py-8 text-center text-gray-400">
                                Belum ada aktivitas. Filter & coba lagi nanti.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Project_PBL_Kel_1\resources\views/riwayat/index.blade.php ENDPATH**/ ?>